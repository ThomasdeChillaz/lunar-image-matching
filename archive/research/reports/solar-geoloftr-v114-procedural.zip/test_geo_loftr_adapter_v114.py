"""Synthetic preprocessing and output-contract tests, with no official weights."""

import inspect
from pathlib import Path
import unittest

import numpy as np
import torch

from geo_loftr_adapter_v114 import (
    GeoLoFTRV114,
    SIZE,
    checkpoint_state,
    native_matches,
    prepare_pair,
    verify_source,
)


def inputs():
    y, x = np.indices((SIZE, SIZE))
    reference = ((x + 3*y) % 256).astype(np.uint8)
    query = np.roll(reference, 8, axis=1)
    depth = np.full(reference.shape, 10.)
    return reference, query, depth


class Stub:
    def __init__(self):
        self.calls = []

    def __call__(self, batch):
        self.calls.append({key: value.clone() for key, value in batch.items()})
        batch.update(mkpts0_f=torch.tensor([[40.25, 32.75], [55.5, 51.5]]),
                     mkpts1_f=torch.tensor([[32.25, 36.75], [47.5, 55.5]]),
                     mconf=torch.tensor([.9, .5]))


class GeoLoFTRTests(unittest.TestCase):
    def test_image_order_reference_only_geometry_and_native_output(self):
        reference, query, depth = inputs()
        model = Stub()
        result = GeoLoFTRV114(model).match(reference, query, depth)
        passed, = model.calls
        self.assertEqual(set(passed), {"image0", "image1", "image1_depth_in"})
        self.assertTrue(all(value.shape == (1, 1, 512, 512) for value in passed.values()))
        self.assertTrue(all(value.dtype == torch.float32 for value in passed.values()))
        self.assertTrue(np.allclose(passed["image0"][0, 0].numpy(), query / 255.))
        self.assertTrue(np.allclose(passed["image1"][0, 0].numpy(), reference / 255.))
        self.assertTrue(np.all(passed["image1_depth_in"][0, 0].numpy() == 1))
        np.testing.assert_array_equal(result.query_xy - result.reference_xy, [[8, -4], [8, -4]])
        self.assertEqual(result.reference_xy[0].tolist(), [32.25, 36.75])
        self.assertEqual(list(inspect.signature(GeoLoFTRV114.match).parameters), [
            "self", "reference", "query", "reference_axial_depth", "reference_mask", "query_mask"])

    def test_invalid_geometry_is_zero_filled_after_valid_only_normalization(self):
        reference, query, depth = inputs()
        depth[1, 1], depth[2, 2], depth[3, 3], depth[4, 4] = np.inf, np.nan, -3., 0.
        depth[5, 5], depth[6, 6] = 20., 99999.
        mask = np.ones(depth.shape, dtype=bool)
        mask[6, 6] = False
        pair = prepare_pair(reference, query, depth, reference_mask=mask)
        self.assertEqual(pair.depth_max_m, 20.)
        self.assertEqual(pair.reference_depth[0, 0], .5)
        self.assertEqual(pair.reference_depth[5, 5], 1.)
        for y in (1, 2, 3, 4, 6):
            self.assertFalse(pair.reference_support[y, y])
            self.assertEqual(pair.reference_depth[y, y], 0.)
        self.assertEqual(depth[6, 6], 99999.)

    def test_outputs_filter_support_and_bounds_without_clipping_subpixels(self):
        reference, query, depth = inputs()
        depth[9, 10] = np.nan
        mask = np.ones(depth.shape, dtype=bool)
        mask[20, 20] = False
        pair = prepare_pair(reference, query, depth, query_mask=mask)
        q = np.array([[5.25, 6.75], [12., 11.], [20., 20.], [511.01, 511.], [1., 1.], [511., 511.]])
        p = np.array([[1.25, 2.75], [10.25, 9.25], [2., 2.], [511., 511.], [0., 0.], [511., 511.]])
        result = native_matches(q, p, [.8, .7, .6, .5, np.nan, .4], pair)
        self.assertEqual((result.raw_pairs, result.invalid_or_out_of_bounds_pairs, result.unsupported_pairs),
                         (6, 2, 2))
        np.testing.assert_array_equal(result.reference_xy, p[[0, 5]])
        np.testing.assert_array_equal(result.query_xy, q[[0, 5]])

    def test_blank_and_empty_depth_do_not_forward(self):
        reference, query, depth = inputs()
        model = Stub()
        adapter = GeoLoFTRV114(model)
        blank = adapter.match(reference, np.zeros_like(query), depth)
        invalid = adapter.match(reference, query, np.zeros_like(depth))
        self.assertEqual(model.calls, [])
        self.assertEqual(blank.reason, "blank_or_uninformative_image")
        self.assertEqual(invalid.reason, "empty_detector_or_reference_depth_support")
        self.assertEqual(blank.reference_xy.shape, (0, 2))

    def test_checkpoint_state_exact_matcher_member_and_duplicate_guard(self):
        tensor = torch.tensor([1.])
        state = checkpoint_state({"models": {"matcher": {"matcher.weight": tensor}}}, torch)
        self.assertEqual(set(state), {"weight"})
        with self.assertRaisesRegex(ValueError, "duplicate"):
            checkpoint_state({"models": {"matcher": {"matcher.weight": tensor, "weight": tensor}}}, torch)
        with self.assertRaisesRegex(ValueError, "models/matcher"):
            checkpoint_state({"state_dict": {"weight": tensor}}, torch)

    def test_source_closure_hashes_and_exact_license(self):
        folder = Path(__file__).resolve().parent
        root = verify_source(folder / "upstream-jpl-e1590f0", folder / "geo_loftr_source_lock_v114.json")
        license_text = (root / "LICENSE").read_text()
        self.assertIn("California Institute of Technology", license_text)
        self.assertIn("SPDX short identifier: Apache-2.0", license_text)
        self.assertFalse((root / "evaluate_mbl.py").exists())


if __name__ == "__main__":
    unittest.main()
