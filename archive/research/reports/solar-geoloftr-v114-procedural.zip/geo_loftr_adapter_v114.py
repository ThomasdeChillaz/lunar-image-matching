"""Reference-only native 512 perspective transfer of official Mars Geo-LoFTR."""

from dataclasses import dataclass
import hashlib
import importlib
from importlib.metadata import version
import json
from pathlib import Path
import sys
import types

import numpy as np


SIZE = 512
REVISION = "e1590f0fe25a7d19b6b22d65c22f9305e46cf868"
WEIGHT_REVISION = "8c66a64949382f0b140ef65e1ae4b3b438fa0d21"
WEIGHT_MEMBER = "loftr/V1/geo/2024_08_29-17_28_02.pt"
WEIGHT_BYTES = 236_338_556
WEIGHT_SHA256 = "275b0dd1c02d63b0a303ec84b3d907e30880847fc36930f9905d3f268c6ef1ad"
ARCHIVE_SHA256 = "ae1e487918e0f4890eebe7456e2577f5487b41046ff7355da8acbb30a982e3db"
LOCK_SHA256 = "ffbd27218338ed636117296f89abc4f8940e1496469a1612dd7060235ffdba1d"
CONFIG = "models/LoFTR_geo/configs/loftr/outdoor/loftr_ds_dense.py"
PROFILE = "official_mars_geo_native512_perspective_reference_axial_depth_transfer"


def file_sha256(path):
    with Path(path).open("rb") as stream:
        digest = hashlib.sha256()
        for data in iter(lambda: stream.read(1 << 20), b""):
            digest.update(data)
    return digest.hexdigest()


def verify_source(source_root, lock_path):
    root = Path(source_root).resolve()
    if file_sha256(lock_path) != LOCK_SHA256:
        raise ValueError("Pinned upstream source-lock bytes differ")
    lock = json.loads(Path(lock_path).read_bytes())
    if lock["schema"] != "geo_loftr_v114_source_closure" or lock["commit"] != REVISION:
        raise ValueError("Require the pinned JPL Geo-LoFTR inference source")
    expected = set(lock["files"])
    present = {str(path.relative_to(root)) for path in root.rglob("*.py")}
    if present != {name for name in expected if name.endswith(".py")} or any(root.rglob("*.pyc")):
        raise ValueError("Use the exact source-only inference closure without extra or compiled modules")
    for name, seal in lock["files"].items():
        path = root / name
        if (path.resolve() != path or path.stat().st_size != seal["bytes"]
                or file_sha256(path) != seal["sha256"]):
            raise ValueError("Pinned JPL source file differs: " + name)
    return root


def lower_config(node, kind):
    if isinstance(node, kind):
        return {key.lower(): lower_config(value, kind) for key, value in node.items()}
    return node


def official_constructor(root):
    """Use an isolated models namespace because the official config imports it."""
    from yacs.config import CfgNode

    sys.dont_write_bytecode = True
    modules = [name for name in sys.modules if name == "models" or name.startswith("models.")]
    if modules and getattr(sys.modules.get("models"), "__path__", None) != [str(root / "models")]:
        raise ValueError("Use a fresh qualification process without another models namespace")
    if not modules:
        package = types.ModuleType("models")
        package.__path__ = [str(root / "models")]
        sys.modules["models"] = package
    module = importlib.import_module("models.LoFTR_geo.src.loftr")
    defaults = importlib.import_module("models.LoFTR_geo.src.config.default")
    for expected, imported in (("models/LoFTR_geo/src/loftr/__init__.py", module),
                               ("models/LoFTR_geo/src/config/default.py", defaults)):
        if Path(imported.__file__).resolve() != root / expected:
            raise ValueError("Official imports escaped the pinned JPL source closure")
    config = defaults.get_cfg_defaults()
    config.merge_from_file(str(root / CONFIG))
    config.LOFTR.CONTRASTIVE = False
    return module.LoFTR_geo, lower_config(config, CfgNode)["loftr"]


def checkpoint_state(payload, torch):
    try:
        raw = payload["models"]["matcher"]
    except (KeyError, TypeError) as error:
        raise ValueError("Official Geo-LoFTR checkpoint has no models/matcher state") from error
    if not isinstance(raw, dict) or not raw:
        raise ValueError("Empty or malformed official matcher state")
    state = {}
    for name, tensor in raw.items():
        if not isinstance(name, str) or not torch.is_tensor(tensor) or tensor.device.type != "cpu":
            raise ValueError("Expected CPU matcher state tensors")
        key = name.removeprefix("matcher.")
        if key in state:
            raise ValueError("Checkpoint has duplicate normalized matcher keys")
        state[key] = tensor
    return state


def _image_mask(image, mask):
    image = np.asarray(image)
    if image.shape != (SIZE, SIZE) or image.dtype != np.uint8:
        raise ValueError("Require original native512 uint8 grayscale detector images")
    support = np.ones_like(image, dtype=bool) if mask is None else np.asarray(mask)
    if support.shape != image.shape or support.dtype != np.bool_:
        raise ValueError("Optional detector masks must be native512 Boolean arrays")
    return image, support


@dataclass(frozen=True)
class PreparedPair:
    query: np.ndarray
    reference: np.ndarray
    reference_depth: np.ndarray
    query_support: np.ndarray
    reference_support: np.ndarray
    depth_max_m: float | None
    reason: str | None


def prepare_pair(reference, query, reference_axial_depth, reference_mask=None, query_mask=None):
    reference, ref_ok = _image_mask(reference, reference_mask)
    query, qry_ok = _image_mask(query, query_mask)
    depth = np.asarray(reference_axial_depth)
    if depth.shape != reference.shape or depth.dtype.kind not in "fiu":
        raise ValueError("Reference geometry must supply a native numeric axial-depth raster in metres")
    ref_ok = ref_ok & np.isfinite(depth) & (depth > 0)
    normalization = float(np.max(depth[ref_ok])) if np.any(ref_ok) else None
    normalized_depth = np.zeros(reference.shape, dtype=np.float32)
    if normalization is not None:
        normalized_depth[ref_ok] = np.asarray(depth[ref_ok] / normalization, dtype=np.float32)
    if normalization is None or not np.any(qry_ok):
        reason = "empty_detector_or_reference_depth_support"
    elif min(np.std(reference[ref_ok]), np.std(query[qry_ok])) < 1.:
        reason = "blank_or_uninformative_image"
    else:
        reason = None
    gray = (np.where(qry_ok, query, 0).astype(np.float32) / 255.,
            np.where(ref_ok, reference, 0).astype(np.float32) / 255.)
    return PreparedPair(*gray, normalized_depth, qry_ok, ref_ok, normalization, reason)


@dataclass(frozen=True)
class MatchResult:
    reference_xy: np.ndarray
    query_xy: np.ndarray
    confidence: np.ndarray
    raw_pairs: int
    invalid_or_out_of_bounds_pairs: int
    unsupported_pairs: int
    reason: str | None


def native_matches(query_xy, reference_xy, confidence, prepared):
    query_xy, reference_xy, confidence = (np.asarray(value, dtype=float) for value in
                                          (query_xy, reference_xy, confidence))
    if (query_xy.ndim != 2 or query_xy.shape[1:] != (2,) or reference_xy.shape != query_xy.shape
            or confidence.shape != (len(query_xy),)):
        raise ValueError("Malformed official fine-coordinate or confidence output")
    native = np.isfinite(confidence) & (confidence >= 0.) & (confidence <= 1.)
    for xy in (query_xy, reference_xy):
        native &= np.isfinite(xy).all(axis=1) & ((xy >= 0.) & (xy <= SIZE - 1.)).all(axis=1)
    valid = np.flatnonzero(native)
    q, r = np.rint(query_xy[valid]).astype(int), np.rint(reference_xy[valid]).astype(int)
    supported = prepared.query_support[q[:, 1], q[:, 0]] & prepared.reference_support[r[:, 1], r[:, 0]]
    selected = valid[supported]
    return MatchResult(reference_xy[selected], query_xy[selected], confidence[selected], len(native),
                       len(native) - len(valid), len(valid) - len(selected),
                       None if len(selected) else "no_valid_native_correspondence")


class GeoLoFTRV114:
    def __init__(self, model, provenance=None):
        self.model = model
        self.provenance = provenance

    @classmethod
    def from_official(cls, source_root, source_lock, checkpoint):
        import torch

        if torch.get_num_threads() != 2:
            raise ValueError("Official CPU qualification requires exactly two Torch threads")
        root = verify_source(source_root, source_lock)
        checkpoint = Path(checkpoint)
        if checkpoint.stat().st_size != WEIGHT_BYTES or file_sha256(checkpoint) != WEIGHT_SHA256:
            raise ValueError("Require the exact official simulated-Mars geo checkpoint member")
        factory, config = official_constructor(root)
        model = factory(config=config).cpu()
        payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
        state = checkpoint_state(payload, torch)
        # The upstream override catches load errors and silently falls back to
        # strict=False. Bypass it after the same matcher.-prefix normalization.
        torch.nn.Module.load_state_dict(model, state, strict=True)
        model.eval().requires_grad_(False)
        return cls(model, dict(
            profile=PROFILE, source_revision=REVISION, source_lock_sha256=LOCK_SHA256,
            checkpoint_sha256=WEIGHT_SHA256, checkpoint_member=WEIGHT_MEMBER, checkpoint_bytes=WEIGHT_BYTES,
            weight_revision=WEIGHT_REVISION, archive_sha256=ARCHIVE_SHA256, cpu_threads=2,
            trainable_parameters=0, total_parameters=sum(p.numel() for p in model.parameters()),
            detector_size=SIZE, internal_size=SIZE, official_config=CONFIG, match_coarse=config["match_coarse"],
            contrastive=False, reference_geometry="valid-only max-normalized perspective axial depth",
            query_truth_inputs=False, acceptance_policy=None,
            runtime={name: version(name) for name in ("torch", "numpy", "einops", "yacs", "kornia")},
        ))

    def match(self, reference, query, reference_axial_depth, *, reference_mask=None, query_mask=None):
        import torch

        prepared = prepare_pair(reference, query, reference_axial_depth, reference_mask, query_mask)
        if prepared.reason is not None:
            return MatchResult(np.empty((0, 2)), np.empty((0, 2)), np.empty(0), 0, 0, 0, prepared.reason)

        def tensor(image):
            return torch.from_numpy(image)[None, None]

        # No internal resize or padding, hence no image scale factors. The
        # upstream padding masks infer a rectangle and cannot represent holes.
        batch = {"image0": tensor(prepared.query), "image1": tensor(prepared.reference),
                 "image1_depth_in": tensor(prepared.reference_depth)}
        with torch.inference_mode():
            self.model(batch)
        output = [batch[name].detach().cpu().numpy() for name in ("mkpts0_f", "mkpts1_f", "mconf")]
        return native_matches(*output, prepared)

    def points(self, reference, query, reference_axial_depth, *, reference_mask=None, query_mask=None):
        result = self.match(reference, query, reference_axial_depth,
                            reference_mask=reference_mask, query_mask=query_mask)
        return result.reference_xy, result.query_xy
