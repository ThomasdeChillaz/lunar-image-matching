"""Run the bounded actual-checkpoint control on generated native inputs only."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import resource
import sys
import time

import numpy as np

from geo_loftr_adapter_v114 import GeoLoFTRV114, SIZE, file_sha256


def qualification(repository, upstream, lock, weight, deadline):
    import cv2
    import torch

    cv2.setNumThreads(1)
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    sys.path.insert(0, str(repository))
    from native_baseline_pose_v7 import propose_pose
    from synthetic import texture

    def clock():
        if datetime.now(timezone.utc) >= deadline:
            raise TimeoutError("Original procedural qualification deadline elapsed")

    started = time.monotonic()
    clock()
    adapter = GeoLoFTRV114.from_official(upstream, lock, weight)
    load_seconds = time.monotonic() - started
    counts = {"matcher": 0, "reference_depth_backbone": 0}

    def hook(name):
        def observe(*_):
            counts[name] += 1
        return observe

    handles = [adapter.model.register_forward_hook(hook("matcher")),
               adapter.model.backbone_depth.register_forward_hook(hook("reference_depth_backbone"))]
    try:
        image = texture(20261101, SIZE)
        shift = np.array([8., -4.])
        transform = np.array([[1., 0., shift[0]], [0., 1., shift[1]]])
        query = cv2.warpAffine(image, transform, (SIZE, SIZE), flags=cv2.INTER_NEAREST)
        depth = np.full(image.shape, 10.)
        intrinsics = np.array([[400., 0., 255.5], [0., 400., 255.5], [0., 0., 1.]])

        def forward(reference, observation, geometry, **kwargs):
            clock()
            before = time.monotonic()
            result = adapter.match(reference, observation, geometry, **kwargs)
            clock()
            return result, time.monotonic() - before

        cold, cold_seconds = forward(image, query, depth)
        known, known_seconds = forward(image, query, depth)
        counted = counts.copy()
        invalid, _ = forward(image, query, np.full_like(depth, np.nan))
        blank, _ = forward(image, np.zeros_like(query), depth)
        zero_mask, _ = forward(image, query, depth, reference_mask=np.zeros_like(image, dtype=bool))
        if counts != {"matcher": 2, "reference_depth_backbone": 2} or counts != counted:
            raise ValueError("Both real controls must reach the actual model and depth backbone")

        reference, target = known.reference_xy, known.query_xy
        median = float(np.median(np.linalg.norm(target - reference - shift, axis=1))) if len(reference) else None
        pose, info = propose_pose(reference, target, depth, intrinsics, np.eye(4), intrinsics)
        angle, distance = None, None
        if pose is not None:
            angle = float(np.degrees(np.arccos(np.clip((np.trace(pose[:3, :3]) - 1.) / 2., -1., 1.))))
            distance = float(np.linalg.norm(pose[:3, 3] - [-.2, .1, 0.]))
        control_empty = all(len(row.reference_xy) == 0 and row.reason is not None
                            for row in (invalid, blank, zero_mask))
        passed = (len(cold.reference_xy) >= 6 and len(reference) >= 6 and median is not None and median <= 1.
                  and angle is not None and angle <= .5 and distance <= .05
                  and info.get("inliers", 0) >= 6 and control_empty)
        clock()
        return dict(
            passed=bool(passed), procedural_only=True, real_or_heldout_images_opened=0,
            provenance=adapter.provenance, actual_pretrained_forward_hooks=counts,
            source_sha256={name: file_sha256(repository / name) for name in ("synthetic.py", "native_baseline_pose_v7.py")},
            seed=20261101, shift_reference_to_query_px=shift.tolist(), original_shape=[SIZE, SIZE],
            native_reference_xy=reference.tolist(), native_query_xy=target.tolist(), match_confidence=known.confidence.tolist(),
            cold_matches=len(cold.reference_xy), matches=len(reference), pose_returned=pose is not None,
            estimated_cam2world=None if pose is None else pose.tolist(), inliers=int(info.get("inliers", 0)),
            median_native_error_px=median, rotation_error_deg=angle, translation_error_m=distance,
            invalid_depth_reason=invalid.reason, invalid_mask_reason=zero_mask.reason, blank_reason=blank.reason,
            control_empty=control_empty, load_seconds=load_seconds, cold_inference_seconds=cold_seconds,
            warm_inference_seconds=known_seconds, elapsed_seconds=time.monotonic() - started,
            peak_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss /
            (1024**2 if sys.platform == "darwin" else 1024),
        )
    finally:
        for handle in handles:
            handle.remove()


def main():
    default = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--deadline-utc", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--upstream", type=Path, default=default / "upstream-jpl-e1590f0")
    parser.add_argument("--source-lock", type=Path, default=default / "geo_loftr_source_lock_v114.json")
    parser.add_argument("--checkpoint", type=Path, default=default / "geo-mars-2024_08_29-17_28_02.pt")
    args = parser.parse_args()
    deadline = datetime.fromisoformat(args.deadline_utc)
    if deadline.utcoffset() is None or deadline <= datetime.now(timezone.utc) or args.output.exists():
        raise ValueError("Require a fresh output and current time-bounded qualification")
    try:
        result = qualification(args.repo_root.resolve(), args.upstream, args.source_lock, args.checkpoint, deadline)
    except Exception as error:
        result = dict(passed=False, procedural_only=True, real_or_heldout_images_opened=0,
                      error_type=type(error).__name__, error=str(error))
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    if not result["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
